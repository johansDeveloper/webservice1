export class Story {
  title: string = '';
  body: string = '';
  publishedAt: string = '';
}
